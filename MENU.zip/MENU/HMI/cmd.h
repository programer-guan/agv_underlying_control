
#ifndef __CMD_H
#define __CMD_H

void CMD_CLEAR(void);

void CMD_PUTC(unsigned char, unsigned char, char);

#endif
